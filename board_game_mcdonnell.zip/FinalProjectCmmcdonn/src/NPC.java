
/**
 * Description of code: Abstract NPC class that extends the entity
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/3/2020
 * Email: cmmcdonn@usc.edu
 */
public abstract class NPC extends Entity{

	/**
	 * @param row
	 * @param col
	 * @param symbol
	 * @param name
	 */
	public NPC(int row, int col, EmojiCharacter symbol, String name) {
		super(row, col, symbol, name);
	}

}
