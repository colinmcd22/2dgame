
/**
 * Description of code: abstract class to hold the name and type of item
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 
 * Email: cmmcdonn@usc.edu
 */
public abstract class Item {
	
	String name;
	String type;

	
	//getter for class
	public Item(String name, String type) {
		this.name = name;
		this.type = type;
	}
	
	
	//getter for class
	public String getName() {
		return this.name;
	}
	


}
