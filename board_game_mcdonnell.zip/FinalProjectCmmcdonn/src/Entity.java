
/**
 * Description of code: Entity class that holds all the super information about the different entities in the game
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/5/2020
 * Email: cmmcdonn@usc.edu
 */
public class Entity extends GameObject{

	//instance variables
	private Location loc;
	private EmojiCharacter symbol;
	protected String name;

	/**
	 * @param row
	 * @param col
	 * @param symbol
	 * @param name
	 */
	public Entity(int row, int col, EmojiCharacter symbol, String name) {
		loc = new Location(row, col);
		this.symbol = symbol;
		this.name = name;
		
	
	}


	
	@Override
	//to String that is overriden
	public String toString() {
		return this.getClass().getSimpleName() + ": " + name + " at " + 
					loc + ", symbol=" + symbol ;
	}





	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((loc == null) ? 0 : loc.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((symbol == null) ? 0 : symbol.hashCode());
		return result;
	}



	@Override
	//equals method for entity objects
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Entity other = (Entity) obj;
		if (loc == null) {
			if (other.loc != null)
				return false;
		} else if (!loc.equals(other.loc))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (symbol != other.symbol)
			return false;
		return true;
	}



	/**
	 * @return the symbol
	 */
	public String getSymbol() {
		return symbol.getSymbol();
	}

	/**
	 * @param symbol the symbol to set
	 */
	public void setSymbol(EmojiCharacter symbol) {
		this.symbol = symbol;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}


	/**
	 * @return the loc
	 */
	public Location getLoc() {
		return loc;
	}


	/**
	 * @param loc the loc to set
	 */
	public void setLoc(Location loc) {
		this.loc = loc;
	}




}

