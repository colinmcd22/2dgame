
/**
 * Description of code: Gameboard class to create the board and fill it with tiles
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 
 * Email: cmmcdonn@usc.edu
 */
public class GameBoard {
	
	private final int MAX_COLS = 6;
	private final int MAX_ROWS = 6;

	private Tile[][] myBoard;
	
	public GameBoard(int boardSize) {
		myBoard = new Tile[boardSize][boardSize]; // square 2d array
		// make each Tile object on the board
		for(int row = 0; row < myBoard.length; row++) {
			for (int col = 0; col < myBoard[row].length; col++) {
				myBoard[row][col] = new Tile(Ground.LAND, row, col);
			}
		}
		
	}
	

	// checks for an edge moving up
	public boolean isEdgeUp(int row) {
		if(row-1 < 0) {
			System.out.println("You can't move up.");
			return true;
		}
		else {
			return false;
		}
	}
	
	// checks for an edge to the left
	public boolean isEdgeLeft(int col) {
		if(col-1 < 0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	// checks for an edge moving down
	public boolean isEdgeDown(int row) {
		if(row+1 >= myBoard.length) {
			return true;
		}
		else {
			return false;
		}
	}
	
	// checks for an edge to the right
	public boolean isEdgeRight(int col) {
		if(col+1 >= myBoard.length) {
			return true;
		}
		else {
			return false;
		}
	}
	
	// updates the board by removing the old character piece and adding the character to the new spot
	public void updateBoard(Player character, Location oldLoc) {
		myBoard[oldLoc.getRow()][oldLoc.getCol()].removePiece(character);
		myBoard[character.getLoc().getRow()][character.getLoc().getCol()].addPiece(character);

	}
	
	public void removePiece(Entity ent, Location loc) {
		myBoard[loc.getRow()][loc.getCol()].removePiece(ent);
	}
	
	// gameBoard constructor that places the object __ UNUSED
	public GameBoard(int boardSize, Player p) {
		this(boardSize);
		placeGameObject(p);
	}
	
	// places a game object in a spot 
	public void placeGameObject(Entity thing) {
		Location loc = thing.getLoc();
		Tile tile = myBoard[loc.getRow()][loc.getCol()];
		tile.addPiece(thing);
	}
	
	
	/**
	 * Give a string 2d version of the array that could be easily printed
	 * 
	 */
	public String getSimpleBoardToDisplay() {
		String board = "\t \t*** Map Of Middle Earth **\n  ";
	
		for (int col = 0; col < MAX_COLS; col++) {
			board += col + "   ";
		}
		board += "\n";
		for(int row = 0; row < myBoard.length; row++) {
			board += row + " ";
			for (int col = 0; col < MAX_COLS; col++) {
				Tile t = myBoard[row][col];
				board += t.getSimpleDisplay() + "  ";
			}
			board += "\n";
		}
		return board;
	}
	
	// simple testing for a board
	public static void main(String[] args) {
		GameBoard b = new GameBoard(6);
		System.out.println(b.getSimpleBoardToDisplay());
	}
	
}

