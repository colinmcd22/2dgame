
/**
 * Description of code: weapons class that is a type of item that adds strength
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/1/2020
 * Email: cmmcdonn@usc.edu
 */
public class Weapons extends Item{

	private int power;
	private int cost;
	
	public Weapons(String name, String type, int power, int cost) {
		super(name,type);
		this.power = power;
		this.cost = cost;
	}
	
	//to string
	public String toString() {
		return super.getName() + ": Grants " + power + " strength. Cost: " + cost + " kills";
	}
	
	//getter for power
	public int getPower() {
		return power;
	}
	
	// getter for cost
	public int getCost() {
		return cost;
	}
}
