
/**
 * Description of code: File writer class that does all the file reading and writing for the entire game, used some online resources for help with this class
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 
 * Email: cmmcdonn@usc.edu
 */

import java.io.FileWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.IOException;


public class WriteFile {

	private String path;
	private boolean append_to_file = false;
	private Map<String, Account> accounts; // map of unique email address to user objects
	private Map<String, Potions> potions;
	private Map<String, Weapons> weapons;
	
	private ArrayList<Item> itemList;
	
	private static final String USER_FILE = "accounts";
	private static final String ITEM_FILE = "items";
	private Helper helper;

	public WriteFile(String file_path) {
		path = file_path;
		accounts = new HashMap<>();
		readAccountsFromFile();
		helper = new Helper();
	}
	
	/**
	 * write file constructor
	 * @param file_path
	 * @param append_value
	 */
	public WriteFile(String file_path, boolean append_value) {
		path = file_path;
		append_to_file = append_value;
		accounts = new HashMap<>();
		potions = new HashMap<>();
		weapons = new HashMap<>();
		readAccountsFromFile();
		readItemsFromFile();
		helper = new Helper();
	}
	
	/**
	 * writes to the file
	 * @param textLine
	 * @throws IOException
	 */
	public void writeToFile(String textLine) throws IOException{
		FileWriter write = new FileWriter(path, append_to_file);
		PrintWriter print_line = new PrintWriter(write);
		
		print_line.printf("%s" + "%n", textLine);
		
		print_line.close();
	}
	
	/**
	 * 
	 * @return accounts
	 */
	public Map<String, Account> getAccountMap(){
		return accounts;
	}
	
	/**
	 * 
	 * @return potions
	 */
	public Map<String, Potions> getPotionMap(){
		return potions;
	}
	
	/**
	 * 
	 * @return weapons
	 */
	public Map<String, Weapons> getWeaponMap(){
		return weapons;
	}
	
	/**
	 * 
	 * @return itemList
	 */
	public ArrayList getItemList() {
		return itemList;
	}
	
	/**
	 * reads the accounts from the file and puts them in a map
	 */
	public void readAccountsFromFile() {
		try(FileInputStream fis = new FileInputStream(USER_FILE);
				Scanner scan = new Scanner(fis))	{  
			while(scan.hasNextLine()) {
				Account a;
				String line = scan.nextLine(); // each line is a user in the systemAccount a;
				Scanner lineReader = new Scanner(line);
				String username = lineReader.next();
				a = new Account(username);
				//once we have a user, put it in map
				accounts.put(username, a);
				lineReader.close();
			}
			
		} catch (FileNotFoundException e) {
			System.err.println("File not found exception in readExistingUsersFromFile");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("IOException in readExistingUsersFromFile");
			e.printStackTrace();
		}
	}
	
	
	/** 
	 * similar to readAccounts method but just reads the items from the file, can read the different data stored in the file
	 */
	public void readItemsFromFile() {
		try(FileInputStream fis = new FileInputStream(ITEM_FILE);
				Scanner scan = new Scanner(fis))	{  
			while(scan.hasNextLine()) {
				String line = scan.nextLine();
				Scanner lineReader = new Scanner(line);
				lineReader.useDelimiter("/"); 
				
				String name = lineReader.next(); 
				String type = lineReader.next();
				String power = lineReader.next();
				String cost = lineReader.next();
				int cos = Integer.parseInt(cost);
				int pow = Integer.parseInt(power);
				if(type.equalsIgnoreCase("p")) {
					Potions p = new Potions(name,type,pow,cos);
					potions.put(name, p);
				}
				else if(type.equalsIgnoreCase("w")) {
					Weapons w = new Weapons(name,type,pow,cos);
					weapons.put(name, w);
				}
				
			}

			
		} catch (FileNotFoundException e) {
			System.err.println("File not found exception in readExistingUsersFromFile");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("IOException in readExistingUsersFromFile");
			e.printStackTrace();
		}
	}
	
	// prints the potion map
	public void printPotions() {
		for(Item key:potions.values()) {
			System.out.println(key);
		}
	}
	
	// prints the weapon map
	public void printWeapons() {
		for(Item key: weapons.values()) {
			System.out.println(key);
		}
	}
	
	// prints all the items
	public void printItems() {
		System.out.println(potions.values());
		System.out.println(weapons.values());
	}
	
	

	
	
	
	/*public void readAccountsFromFile() {
		try(FileInputStream fis = new FileInputStream(USER_FILE);
				Scanner scan = new Scanner(fis))	{  
			while(scan.hasNextLine()) {
				String line = scan.nextLine(); // each line is a user in the system
				Account account = parseLineToUser(line);
				//once we have a user, put it in map
				accounts.put(account.getUsername(), account); //unique email maps to ONE user in the system
			}

		} catch (FileNotFoundException e) {
			System.err.println("File not found exception in readExistingUsersFromFile");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("IOException in readExistingUsersFromFile");
			e.printStackTrace();
		}

	}*/
	
	public Account createNewUser(String username) {
		
		// if the user already exists, don't want to create one
		if(accounts.containsKey(username)) {
			System.err.println("Can't create a user with this email, because they already exist in system");
			return null;
		}
		else {
			//GET THE DATA NEEDED TO MAKE THE USER
			String name = helper.inputLine ("Please enter your username : "); 
			
			Account a =  new Account(name);
			accounts.put(name, a);// add the user to the map
			return a;
		}
	}
	
	private Account parseLineToUser(String line) {

		Account a;

		// line needs to be broken apart into tokens. (Use Scanner)
		Scanner lineReader = new Scanner(line);
		//lineReader.useDelimiter("/"); // instead of white space, use the / as the thing that breaks the line apart
		// good lines will either have 3 tokens or 5 tokens.

		String username = lineReader.next(); // email is always first in the line from the file// name is always second in the line from the file
		//String password = lineReader.next(); // Password is always third in the line from the file

		a = new Account(username);
		lineReader.close();
		return a;

	}
	
	private void writeUsersToFile() {

		System.out.println("write users to file method, using: " + USER_FILE);
		try (FileOutputStream fos = new FileOutputStream(USER_FILE);
			PrintWriter pw = new PrintWriter(fos)) {
			// take each user in the map and write it to the file.
			for(String key: accounts.keySet()) {
				Account a = accounts.get(key);
				// print users email/name/password/q/a
				pw.println(a.toFileString());
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} // automatically close resources at end
		
		
	}
}
