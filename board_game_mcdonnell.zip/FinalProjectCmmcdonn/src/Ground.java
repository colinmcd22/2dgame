
/**
 * Description of code: Ground enum to hold the type of piece that is initially placed
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 
 * Email: cmmcdonn@usc.edu
 */
public enum Ground{
	LAND ("--");

	private String symbol;
	
	
	private Ground(String sym) {
		this.symbol = sym;
	}
	
	// toString method
	public String toString() {
		return symbol;
	}
	
	//allows the type of ground to be given (only 1 ground for now)
	public String getType() {
		return this.name().toLowerCase();
	}

	
}
