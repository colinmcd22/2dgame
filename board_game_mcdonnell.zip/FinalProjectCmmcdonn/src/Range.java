
/**
 * Description of code: Range class that can hold different ranges (hardly used)
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/1/2020
 * Email: cmmcdonn@usc.edu
 */
public class Range {
	private final int min;
	private final int max;
	private int current; // The current Value in the range 
	
	public Range(int min, int max, int current) {
		this.min = min;
		this.max = max;
		setCurrent(current);
		
	}
	
	/**
	 * @param min
	 * @param max
	 */
	public Range(int min, int max) {
		this(min, max, (min+max)/2);
	
	}


	
	// to String
	public String toString() {
		if(min == max && max == current) {
			return "Value:"+this.min;
		}
		if(min == 1 && max == 100) {
			return "" + current;
		}
		return current + " of [" + min + " - " + max +"]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + current;
		result = prime * result + max;
		result = prime * result + min;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Range other = (Range) obj;
		if (current != other.current)
			return false;
		if (max != other.max)
			return false;
		if (min != other.min)
			return false;
		return true;
	}

	/**
	 * @return the current
	 */
	public int getCurrent() {
		return current;
	}

	public boolean increaseCurrentValue(int amount) {
		boolean changed = false;
		if(amount > 0) {
			if(setCurrent(current + amount)) {
				changed = true;
			}
			else if(current + amount > max) {
				this.current = max;
				changed = true;
			}
		}
		return changed;
	}
	public boolean decreaseCurrentValue(int amount) {
		boolean changed = false;
		if(amount > 0) {
			if(setCurrent(current - amount)) {
				changed = true;
			}
			else if(current - amount < min) {
				setCurrent(min);
				changed = true;
			}
		}
		return changed;
	}
	/**
	 * @param current the current to set
	 */
	public boolean setCurrent(int current) {
		boolean set = false;
		if(current >= min && current <= max) {
			this.current = current;
			set = true;
		}
		return set;
	}
	

	/**
	 * @return the min
	 */
	public int getMin() {
		return min;
	}

	/**
	 * @return the max
	 */
	public int getMax() {
		return max;
	}
	
}

