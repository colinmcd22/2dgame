
/**
 * Description of code: Enum for emoji characters to hold the string
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/5/2020
 * Email: cmmcdonn@usc.edu
 */

/** constructor
 */
public enum EmojiCharacter {
	//Example: 👻 is unicode:  U+1F47B which in source code is: 	"\uD83D\uDC7B"
	// see here" http://www.fileformat.info/info/unicode/char/1f47b/index.htm
	// emoji characters are too big for standard java characters, so they have to be strings
	// that are actually displayed 2 characters each
	 
	ALIEN_MONSTER("👾"),
	ALIEN("👽"),
	BUNNY_VAMPIRE("🐰"),
	CRYSTAL_BALL("🔮"),
	COVID19("🦠"),
	CYCLOPS("👁️"),
	DRAGON("🐉"), 
	GIANT("🗿"), 
	GOBLIN("👺"),
	GHOST("👻"),
	KITTEN("🐈"),
	MAN_WALKING("🚶‍♂️"),
	MERMAID("🧜‍♀️"),
	OCTOPUS("🐙"),
	OGRE("👹"),
	PERSON("🧑"),
	PIXIE("🧚"),
	QUACKEN("🦆"), 
	SATAN("👿"),
	SLIMY_BLOB("☄️"),
	SKULL ("☠️"),
	VAMPIRE_BAT("🦇"),
	VAMPIRE_MAN("🧛🏼,"),
	VAMPIRE_WOMAN("🧛🏼‍♀️"),
	UNICORN("🦄"),
	WIZARD("🧙"),
	WOMAN_WALKING("🚶🏽‍♀️"),
	ZOMBIE("🧟"),
	TALION("🕴"),
	SHIV("👨‍🎤"),
	MAGIC_ZOMBIE("🧞‍♂️"),
	FLYING_ZOMBIE("🧚‍♀️"),
	CASTLE("🏰 "),
	X("❌");
	
	//instance variable
	private String picture;
	//passes through picture
	private EmojiCharacter(String p) {
		picture = p;
	}
	
	//getter for symbol
	public String getSymbol() {
		return picture;
	}
	


}

