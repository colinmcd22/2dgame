
/**
 * Description of code: Type of undead with more strength, but less health
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/8/2020
 * Email: cmmcdonn@usc.edu
 */


public class MagicUndead extends Undead{

	/**
	 * @param row
	 * @param col
	 * @param symbol
	 * @param name
	 */
	
	public MagicUndead(int row, int col, EmojiCharacter symbol, String name) {
		super(row, col, symbol, name);
		this.strength = 6;
		this.health = 3;
	}
	
}
