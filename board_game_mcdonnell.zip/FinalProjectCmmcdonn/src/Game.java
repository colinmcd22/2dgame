
import java.io.IOException;
import java.util.ArrayList;

import java.util.Map;



/**
 * Description of code: outward facing system, game class brings together all of the different elements to enact the game. Could be worth adding an abstract game class
 * that Game extends to hold the information nicer
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/5/2020
 * Email: cmmcdonn@usc.edu
 */
public class Game {
	
	private final static int ROWS = 6; // rows for the board - its a square so cols is not used
	private final int COLS = 6;
	private final int START_ROW = 0;
	private final int START_COL = 3;
	private final int NUM_ENEMIES = 8;
	private final int NUM_ALLIES = 7;
	
	//keep going booleans
	private static boolean gameOver = false;
	private static boolean playAgain = true;
	private Location oldLoc;
	
	private String file_name = "accounts";
	private WriteFile data;
	
	private Player[] playerList;
	
	private static Account currentAccount;
	private Account guestAccount;
	private Item purchasedItem;
	
	private static Helper helper = new Helper();
	private  Player character;
	
	private ArrayList itemList;
	private String enemyNames[] = {"Harry", "Zulag", "Bobby the Butcher", "Beans", "Chong", "Ziggs", "Barry", "Krimp"};//names
	private Undead[] enemyList = new Undead[NUM_ENEMIES];
	private AllyNPC[] allyList = new AllyNPC[NUM_ALLIES];
	
	private GameBoard boardGame;//boardGame to manipulate
	private Undead[][] takenEnemySpots = new Undead[ROWS][COLS]; //booleans to track the spots taken by enemies and allys for easier refernce
	private AllyNPC[][] takenAllySpots = new AllyNPC[ROWS][COLS];
	private Map<String, Account> accounts;//maps of different data to be held
	private Map<String, Potions> potions;
	private Map<String, Weapons> weapons;
	

	
	// constructor to make the game and set up all necessary elements, initializes all variables
	public Game() throws IOException {
		playerList = new Player[2];
		data = new WriteFile(file_name, true);
		helper = new Helper();
		accounts = data.getAccountMap();
		potions = data.getPotionMap();
		weapons = data.getWeaponMap();
		itemList = data.getItemList();
		guestAccount = new Account("Guest Account");
		currentAccount = guestAccount;
		login();
		setUpCharacters();
		printIntro();
		boardGame = new GameBoard(ROWS, characterSelection());
		addCastle();
		generateEnemies();
		generateAllies();
		System.out.println(boardGame.getSimpleBoardToDisplay());
		helper.printCommands();
		
	}

	
	// main game method that plays the game by updating the board and reprinting it, continually updates the spot and allows for 
	// fighting and trading to be done, checks if its on the tower, continues until gameOver changes
	public void playGame() {
		while(!gameOver) {
			updateSpot();
			fight(character);
			trade(character);
			System.out.println(boardGame.getSimpleBoardToDisplay());
			onTower();
		}
	}
	
	/** updates the spot for the character based on moves/ also can print the characters/ update board functionality
	 * can also quit the game or ask for more help
	 */
	private void updateSpot() {
		Location loc = character.getLoc();
		oldLoc = character.getLoc();
		int row = loc.getRow();
		int col = loc.getCol();
		
		Command command = helper.getCommand();
		
		if(command.equals(Command.MOVE_UP)){
			if(!boardGame.isEdgeUp(row)) {
				row = row - 1;
				Location newLoc = new Location(row,col);
				character.setLoc(newLoc);
				boardGame.updateBoard(character,loc);
			}
		}
		else if(command.equals(Command.MOVE_LEFT)) {
			if(!boardGame.isEdgeLeft(col)) {
				col = col -1;
				Location newLoc = new Location(row, col);
				character.setLoc(newLoc);
				boardGame.updateBoard(character, loc);
			}
		}
		else if(command.equals(Command.MOVE_DOWN)) {
			if(!boardGame.isEdgeDown(row)) {
				row = row + 1;
				Location newLoc = new Location(row, col);
				character.setLoc(newLoc);
				boardGame.updateBoard(character, loc);
			}
		}
		else if(command.equals(Command.MOVE_RIGHT)) {
			if(!boardGame.isEdgeRight(col)) {
				col = col+1;
				Location newLoc = new Location(row, col);
				character.setLoc(newLoc);
				boardGame.updateBoard(character, loc);
			}
		}
		else if(command.equals(Command.PRINT_CHARS)) {
			System.out.println("Enemies: Undead(🧟) 4 Str/4 HP | Flying Undead(🧚) 1 Str/11 HP | Magic Undead(🧞‍♂️‍)️️ 5 Str/ 1 HP");
			System.out.println("Allies: Trader(🚶) - Can buy items based on # of enemies killed| GiftBearer(🧑) - Gives a random gift");
				//will implement enemy NPCs later or in V2
			}
		else if(command.equals(Command.QUIT)) {
			System.out.println("Thanks for playing.");
			gameOver = true;
		}
		else if(command.equals(Command.HELP)){
			helper.printCommands();
			System.out.println("The goal of the game is to make it to the tower. Each enemy you fight will take away health, and you will lose 2 strength. \n"
					+ "If an enemy has more Health than you have Strength, it will take multiple turns to eliminate them. \n You can look at the stats of each character by pressing \"P\". "
					+ " \n There are randomly generated allies (traders and giftbearers) that you can interact with as well to help destroy the enemies.");
		}
	}
	
	/** setter method for the game winning condition
	 * 
	 */
	private void onTower() {
		if(character.getLoc().getRow() == ROWS -1 && character.getLoc().getCol() == ROWS - 1) {
			System.out.println("You made it to the tower and were able to save Middle Earth with the power of the Ring! Congratulations, savior.");
			gameOver = true;
		}
	}
	
	/**
	 * Fighting method to compare the player and the enemy. Player can be killed, kill the enemy, or hurt the enemy
	 * @param p - unnecessary but nice
	 */
	private void fight(Player p) {
		int hp = p.getHealth();
		int str = p.getStrength();
		int row = p.getLoc().getRow();
		int col = p.getLoc().getCol();
		if(takenEnemySpots[row][col] != null) {
			int enemyHp = takenEnemySpots[row][col].getHealth();
			int enemyStr = takenEnemySpots[row][col].getStrength();
			String enemyName = takenEnemySpots[row][col].getName();
			System.out.print("You are fighting " + enemyName + ". This enemy has " + enemyHp + " health and " + enemyStr + " strength. You lose 2 strength each time you fight.");
			hp = hp - enemyStr;
			enemyHp = enemyHp - str;
			p.setHealth(hp);
			p.subtractStrength(2);
			if(hp <= 0) { //you died
				System.out.print("Game over. You died. This enemy was too strong.\n Try building up some health before fighting by buying a potion.");
				gameOver = true;
			}
			else if(enemyHp <=0){ //killed the enemy
				System.out.println(" You killed " + enemyName + "! You have " + hp + " health left.");
				p.addKill();
				System.out.println("You now have " + p.getKills() + " kills.");
				currentAccount.addScore(1);
				boardGame.removePiece(takenEnemySpots[row][col], takenEnemySpots[row][col].getLoc());
				takenEnemySpots[row][col] = null;
			}
			else { // unable to kill the enemy
				System.out.println(" You were unable to kill " + enemyName + " in one turn. \n" + enemyName + " now has " + enemyHp + " health left. "
						+ "You were moved back to your previous spot.");
				boardGame.removePiece(p, p.getLoc());
				takenEnemySpots[row][col].setHealth(enemyHp);
				p.setLoc(oldLoc);
				boardGame.placeGameObject(p);
			}
		}
	}
	
	/**
	 * trading method  that checks for a trader or giftbearer
	 * @param p - unnecessary
	 */
	public void trade(Player p) {
		int row = p.getLoc().getRow();
		int col = p.getLoc().getCol();
		if(takenAllySpots[row][col] != null) {
			String allyName = takenAllySpots[row][col].getName();
			System.out.println("Hello, " + p.getName() + "! I am " + allyName + "." );
			if(takenAllySpots[row][col] instanceof Trader) {
				data.printItems();
				purchaseItem();
			}
			else if(takenAllySpots[row][col] instanceof GiftBearer) {
				receiveGift();
			}
		}
	}
	
	/**
	 * allows the user to purchase an item with their kills, checks the different items in the list (could make this more generalizable)
	 */
	public void purchaseItem() {
		int power;
		int cost;
		int row = character.getLoc().getRow();
		int col = character.getLoc().getCol();
		String purchase = helper.inputItems("What would would like to purchase? Type the item name as you see it (or type quit). \n You have " + character.getKills() + " kills to use.", "major health", "lesser health", "small sword", "dagger", "might sword","quit");
		switch(purchase) {
		case "major health":
			power = potions.get("major health").getPower();
			cost = potions.get("major health").getCost();
			if(character.getKills() >= cost) {
				character.subtractKills(cost);
				character.addHealth(power);
				boardGame.removePiece(takenAllySpots[row][col], takenAllySpots[row][col].getLoc());
				takenAllySpots[row][col] = null;
			}
			else {
				System.out.println("You have not eliminated enough enemies.");
			}
			break;
		case "lesser health":
			power = potions.get("lesser health").getPower();
			cost = potions.get("lesser health").getCost();
			if(character.getKills() >= cost) {
				character.subtractKills(cost);
				character.addHealth(power);
				boardGame.removePiece(takenAllySpots[row][col], takenAllySpots[row][col].getLoc());
				takenAllySpots[row][col] = null;
			}
			else {
				System.out.println("You have not eliminated enough enemies.");
			}
			break;
		case "small sword":
			power = weapons.get("small sword").getPower();
			cost = weapons.get("small sword").getCost();
			if(character.getKills() >= cost) {
				character.subtractKills(cost);
				character.addStrength(power);
				boardGame.removePiece(takenAllySpots[row][col], takenAllySpots[row][col].getLoc());
				takenAllySpots[row][col] = null;
			}
			else {
				System.out.println("You have not eliminated enough enemies.");
			}
			break;
		case "mighty sword":
			power = weapons.get("mighty sword").getPower();
			cost = weapons.get("mighty sword").getCost();
			if(character.getKills() >= cost) {
				character.subtractKills(cost);
				character.addStrength(power);
				boardGame.removePiece(takenAllySpots[row][col], takenAllySpots[row][col].getLoc()); // removes the trader from board
				takenAllySpots[row][col] = null;
			}
			else {
				System.out.println("You have not eliminated enough enemies.");
			}
			break;
		case "dagger":
			power = weapons.get("dagger").getPower();
			cost = weapons.get("dagger").getCost();
			if(character.getKills() >= cost) {
				character.subtractKills(cost);
				character.addStrength(power);
				boardGame.removePiece(takenAllySpots[row][col], takenAllySpots[row][col].getLoc());
				takenAllySpots[row][col] = null;
			}
			else {
				System.out.println("You have not eliminated enough enemies.");
			}
			break;
		case "exit":
			System.out.println("Come again!");
			break;
		}
		System.out.println("You now have " + character.getHealth() + " health and " + character.getStrength() + " strength. Thanks for coming!");
	}
	
	
	/** 
	 * allows the user to receive a gift from the giftbearer, randomly adds health or strength
	 */
	private void receiveGift() {
		int row = character.getLoc().getRow();
		int col = character.getLoc().getCol();
		System.out.println("You will recieve a random gift to boost your health or strength! ");
		 int rand_int1 = (int) (Math.random() * (2 - 0 + 1) + 0);
		 int rand_int2 = (int) (Math.random() * (6 - 1 + 1) + 0);
		 if(rand_int1 == 1) {
			 character.addHealth(rand_int2);
			 System.out.println("You were granted " + rand_int2 + " health. You now have " + character.getHealth());
		 }
		 else {
			 character.addStrength(rand_int2);
			 System.out.println("You were granted " + rand_int2 + " strength. You now have " + character.getStrength());
		 }
			boardGame.removePiece(takenAllySpots[row][col], takenAllySpots[row][col].getLoc());
			takenAllySpots[row][col] = null;
	}
	
	// selects a random name from a list of names to assign to enemies and alleis
	private String generateNames() {
		int randName = (int) ((Math.random() * ((enemyNames.length - 1) + 1)) + 0);
		return enemyNames[randName];
	}
	
	// creates enemies based on random criteria and places them on the board, making sure they are not overlapping
	private void generateEnemies() {
		for(int i = 0; i < enemyList.length; i++) {
			int randRow = (int) ((Math.random() * ((ROWS - 2) + 1)) + 1);
			int randCol = (int) ((Math.random() * ((COLS - 2) + 1)) + 1);
			if(randRow >= 3 && randCol <=3 && takenEnemySpots[randRow][randCol]==null && takenAllySpots[randRow][randCol] == null) {
				MagicUndead undead = new MagicUndead(randRow, randCol, EmojiCharacter.MAGIC_ZOMBIE, generateNames());
				boardGame.placeGameObject(undead);
				enemyList[i] = undead;
				takenEnemySpots[randRow][randCol] = undead;
			}
			else if(randCol >= 3 && randRow <=3 && takenEnemySpots[randRow][randCol]== null && takenAllySpots[randRow][randCol] == null) {
				FlyingUndead undead = new FlyingUndead(randRow, randCol, EmojiCharacter.FLYING_ZOMBIE, generateNames());
				boardGame.placeGameObject(undead);
				enemyList[i] = undead;
				takenEnemySpots[randRow][randCol] = undead;
			}
			else if(takenEnemySpots[randRow][randCol] == null && takenAllySpots[randRow][randCol] == null){
				Undead undead = new Undead(randRow, randCol, EmojiCharacter.ZOMBIE, generateNames());
				boardGame.placeGameObject(undead);
				enemyList[i] = undead;
				takenEnemySpots[randRow][randCol] = undead;
			}
		}
	}
	
	// generates allies the same way as enemies, creates new allies and adds them to the board
	private void generateAllies() {
		for(int i = 0; i < allyList.length; i++) {
			int randRow = (int) ((Math.random() * ((ROWS - 2) + 1)) + 1);
			int randCol = (int) ((Math.random() * ((COLS - 2) + 1)) + 1);
			if(randRow >= 3 && randCol <=3 && takenEnemySpots[randRow][randCol] == null && takenAllySpots[randRow][randCol] == null) {
				GiftBearer ally = new GiftBearer(randRow, randCol, EmojiCharacter.PERSON, generateNames());
				boardGame.placeGameObject(ally);
				takenAllySpots[randRow][randCol] = ally;
				allyList[i] = ally;
			}
			else if(randCol >= 3 && randRow <=3 && takenEnemySpots[randRow][randCol] == null && takenAllySpots[randRow][randCol] == null) {
				Trader ally = new Trader(randRow, randCol, EmojiCharacter.MAN_WALKING, generateNames());
				boardGame.placeGameObject(ally);
				takenAllySpots[randRow][randCol] = ally;
				allyList[i] = ally;
			}
		}
	}
	
	// this method sets up the characters by creating the two you can play as 
	private void setUpCharacters() {
		Player talion= new Player(START_ROW, START_COL, EmojiCharacter.TALION, "Talion", 10, 10, 0, new ArrayList<>());
		playerList[0] = talion;
		playerList[1] = new Player(START_ROW, START_COL, EmojiCharacter.SHIV, "Shiv", 7, 13, 0, new ArrayList<>());
		
		}
	
	// adds the castle enum to the board
	private void addCastle() {
		Castle castle = new Castle(ROWS-1, COLS-1, EmojiCharacter.CASTLE, "Castle");
		takenAllySpots[ROWS-1][COLS-1] = castle;
		boardGame.placeGameObject(castle);
	}
	
	// allows the player to select which character they want to use
	public Player characterSelection() {
		System.out.println("\nYou may choose which character to play as. Each character has different health and strength.\n"
				+ " Strength determines how much damage an enemy does do to you and how much you do to them. \n");
		
		// print characters out
		for(int i = 0; i < playerList.length; i++) {
			System.out.println(playerList[i]);
		}
		String choice = helper.inputWord("Select a character option.", "Talion", "Shiv");
		if(choice.equalsIgnoreCase("Talion")) {
			character = playerList[0];
		}
		else if(choice.equalsIgnoreCase("Shiv")) {
			character = playerList[1];
		}
		System.out.println("You selected " + character.getName() + ". " + character);
		return character;
		
	}
	// prints out a basic intro to the game
	public void printIntro() {
		System.out.println("Welcome to Middle Earth, " + currentAccount.getUsername() + ". There is a war going on between the undead and the humans. You have the ring that can end the war.");
		System.out.println("There is an ancient tower a few miles North that can use the power of the ring to send all the undead back to their grave.");
		System.out.println("The path is dangerous with friends and foes along the way. The fate is in your hands.");
		
		System.out.println("\nYour goal is to make it to the tower. There are many enemies along the way, but you will also meet some friends.");
		
		
	}
	
	// login method to allow account to be saved
	private void login() throws IOException {
		helper.print("Welcome to Rise of the Undead! Please sign in or create an account to save your progress.");
		String word = helper.inputWord("Would you like to sign in to your account or create a new account?\n" +
				"Type: \"signin\" or \"create\"", "signin", "create");
		if (word.equalsIgnoreCase("signin")) {
			signin();
		} 
		else {
			createAccount();
		}
	}
	
	     
	
	// allows for signin functionality to an already created account, passes in the user name entered
	private void signin(String username) throws IOException {
		if(accounts.containsKey(username)) {
			currentAccount = accounts.get(username);
			helper.print("Welcome back " + currentAccount.getUsername());
		}
		else {
			boolean createNew = helper.inputYesNoAsBoolean("Didn't find an account with that username. Would you like to create an account with this username? (y/n)");
			if(createNew) {
				currentAccount = new Account(username);
				data.writeToFile(username);
				
			}
			else {
				helper.print("Continuing as a guest");
				currentAccount = guestAccount;
			}	

		}
	}
	
	// signs in without putting in the username
	private void signin() throws IOException {
		String account =  helper.inputLine("Please \"login\" by giving me your username:");
		signin(account);
	}
	
	//allows the player to create a new account
	private void createAccount() throws IOException {
		String username =  helper.inputLine("Please create a username:");
		if(accounts.containsKey(username)) {
			System.out.println("There is already an account associated with this username.");
			signin(username);
		}
		else {
			currentAccount = new Account(username);
			data.writeToFile(username);
		}
	}

	
	// main method that makes a game object and then loops while playAgain is true
	public static void main(String[] args) throws IOException {
		
		//playGame(game);
		//game.printIntro();
		//game.printGame();
		while(playAgain) {
			Game game = new Game();
			game.playGame();
			System.out.println("Thanks for playing " + currentAccount.getUsername());
			System.out.println("You have a score of " + currentAccount.getScore() + " kills");
			playAgain = helper.inputYesNoAsBoolean("Would you like to play again? (y/n)");
			if(playAgain) {
				gameOver = false;
			}
			else
				System.out.println("Goodbye!");
		}
	}
	
	
}
