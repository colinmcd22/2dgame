
/**
 * Description of code: Type of undead with specific hp/str
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/5/2020
 * Email: cmmcdonn@usc.edu
 */
public class FlyingUndead extends Undead{

	/**
	 * @param row
	 * @param col
	 * @param symbol
	 * @param name
	 */

	
	public FlyingUndead(int row, int col, EmojiCharacter symbol, String name) {
		super(row, col, symbol, name);
		this.strength = 2;
		this.health = 11;
		
	}

}
