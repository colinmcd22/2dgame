
/**
 * Description of code: GiftBearer Ally that gives a random gift
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 
 * Email: cmmcdonn@usc.edu
 */
public class GiftBearer extends AllyNPC {

	/**
	 * @param row
	 * @param col
	 * @param symbol
	 * @param name
	 */
	public GiftBearer(int row, int col, EmojiCharacter symbol, String name) {
		super(row, col, symbol, name);

	}

}
