
/**
 * Description of code: Human class to hold health and strength for player
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/8/2020
 * Email: cmmcdonn@usc.edu
 */
public abstract class Human extends Entity {

	protected int health;
	protected int strength;
	

	/**
	 * 
	 * @param row
	 * @param col
	 * @param symbol
	 * @param name
	 * @param currentHP
	 * @param currentStr
	 */
	public Human(int row, int col, EmojiCharacter symbol, String name, int currentHP, int currentStr) {
		super(row, col, symbol, name);
		this.health = currentHP; 
		this.strength = currentStr;
	}

	/**
	 * @param name2
	 */

	/**
	 * to string
	 */
	public String toString() {
		return this.name + " has " + this.health + " health and " + this.strength + " strength.";
	}
	
	//getter for name
	public String getName() {
		return this.name;
	}
	
	//prints descriptions for characters
	public String talionDesc() {
		return "Talion is a great warrior that wields a sword to slice and dice his enemies. He is a well balanced fighter with medium health and strength.";
	}
	
	public String shivDesc() {
		return "Shiv is a nimble warrior that wields daggers. He has very strong attacks, but does not have much strength.";
	}

	

	

}
