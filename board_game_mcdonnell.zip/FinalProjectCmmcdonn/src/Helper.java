import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Description of code:
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 
 * Email: cmmcdonn@usc.edu
 */
public class Helper {

	private Scanner sc;
	
	
	/**
	 * Constructor sets up a Scanner to be used by the class in order to read input from the standard console window (System.in)
	 */
	public Helper() {
		sc = new Scanner(System.in);
	}
	
	/**
	 * Short-cut helper method for print
	 * @param output: The String to be printed
	 */
	public void print(String output) {
		System.out.println(output);
	}
	/**
	 * Short-cut helper method that prints a String with a series of stars around it.
	 * @param output: The String to be printed
	 */
	public void printPretty(String output) {
		System.out.println("***********************************************************************************************");
		System.out.println(output);
		System.out.println("***********************************************************************************************");
	}
	
	/**
	 * Short-cut helper method that prints a List with a series of stars around it.
	 * @param output: The List to be printed
	 */
	public void printPretty(ArrayList list) {
		System.out.println("***********************************************************************************************");
		for(Object o: list) {
			System.out.println(o);
		}
		System.out.println("***********************************************************************************************");
	}
	/**
	 * Prompt the user and read one line of text as a String
	 * @param prompt: the question to ask the user
	 * @return: a line of user input (including spaces, until they hit enter)
	 */
	public String inputLine(String prompt) {
		System.out.print(prompt + "\n>");
		return sc.nextLine();
	}
	
	/**
	 * Prompt the user and read one word of text as a String
	 * @param prompt: the question to ask the user
	 * @return: a one word String - if the user enters multiple words, all other input until the return will be discarded.
	 */
	public String inputWord(String prompt) {
		System.out.print(prompt + "\n>");
		String word = sc.next();
		sc.nextLine(); // remove any "garbage" (like extra whitespace or the return key) after the one word that is read in
		return word;
	}
	
	/**
	 * Prompt the user and read one word - which must match either option1 or option2 parameters.
	 * @param prompt: the question to ask the user (should include the two valid options the user should choose from)
	 * @param option1 : One string option for the user to choose.
	 * @param option2: the other string option for the user to choose.
	 * @return: A string matching either option1 or option2
	 */
	public String inputWord(String prompt, String option1, String option2) {
		
		System.out.print(prompt + "\n>");
		String word = sc.nextLine();
		while(! (word.equalsIgnoreCase(option1) || word.equalsIgnoreCase(option2))) {
			System.out.println(word + " not recognized as " + option1 + " or " + option2);
			System.out.println(prompt);
			word = sc.nextLine();
		}
		return word;
	}
	
	public String inputItems(String prompt, String item1, String item2, String item3, String item4, String item5, String item6) {
		System.out.print(prompt + "\n>");
		String word = sc.nextLine();
		while(! (word.equalsIgnoreCase(item1) || word.equalsIgnoreCase(item2) || word.equalsIgnoreCase(item3) || word.equalsIgnoreCase(item4) || word.equalsIgnoreCase(item5) || word.equalsIgnoreCase(item6))) {
			System.out.println(word + " not recognized.");
			System.out.println(prompt);
			word = sc.nextLine();
		}
		return word;
	}
	
	public String inputCommands(String prompt, String option1, String option2, String option3, String option4, String option5, String option6, String option7) {
		
		System.out.print(prompt + "\n>");
		String word = sc.nextLine();
		while(! (word.equalsIgnoreCase(option1) || word.equalsIgnoreCase(option2) || word.equalsIgnoreCase(option3) || word.equalsIgnoreCase(option4) || word.equalsIgnoreCase(option5) || word.equalsIgnoreCase(option6) || word.equalsIgnoreCase(option7) || word.equalsIgnoreCase("help"))) {
			System.out.println(word + " not recognized.");
			System.out.println(prompt);
			word = sc.nextLine();
		}
		return word;
	}
	
	/**
	 * Prompt the user and read an int, clearing whitespace or the enter after the number
	 * @param prompt: the question to ask the user 
	 * @return: an int 
	 */
	public int inputInt(String prompt) {
		System.out.print(prompt + "\n>");
		// if scanner does not see an int, get rid of garbage and ask again.
		while (!sc.hasNextInt()) {
			String garbage = sc.nextLine();
			System.out.println("Didn't recognize " + garbage + " as an integer...");
			System.out.println(prompt);
		}
		int num = sc.nextInt();
		sc.nextLine(); // clear the buffer
		return num;
	}
	
	/**
	 * Prompt the user and read an int between (inclusive) of minValue and maxValue, clearing whitespace or the enter after the number
	 * @param prompt: the question to ask the user 
	 * @return: an int between minValue and maxValue
	 */
	public int inputInt(String prompt, int minValue, int maxValue) {
		int num = inputInt(prompt); // make sure you get a num
		while(num < minValue || num > maxValue) {
			System.out.println(num + " is not in the allowed range: [" + minValue
					+ "-" + maxValue + "]");
			num = inputInt(prompt); // make sure you get a num

		}
		return num;
	}
	

	/**
	 * Prompt the user and read an int between (inclusive) of minValue and maxValue, 
	 * (or sentinel quitValue) clearing whitespace or the enter after the number
	 * @param prompt the question to ask the user
	 * @param minValue
	 * @param maxValue
	 * @param quitValue
	 * @return an int between minValue and maxValue (or quit sentinel value)
	 */
	public int inputInt(String prompt, int minValue, int maxValue, int quitValue) {
		int num = inputInt(prompt); // make sure you get a num
		while(num != quitValue && (num < minValue || num > maxValue)) {
			System.out.println(num + " is not in the allowed range: [" + minValue
					+ "-" + maxValue + "] (or " + quitValue + " to quit)");
			num = inputInt(prompt); // make sure you get a num
		}
		return num;
	}
	/**
	 * Prompt the user and read a postive (>=0) int, clearing whitespace or the enter after the number
	 * @param prompt: the question to ask the user 
	 * @return: an int >= 0
	 */
	public int inputPostiveInt(String prompt) {
		// use the fact inputInt works....
		int num = inputInt(prompt); // off-loaded work
		while(num < 0) { //not positive....
			System.out.println("Need a positive number, try again");
			num = inputInt(prompt);
		}
		return num;
		
	}
	/**
	 * Prompt the user and read a floating point number, clearing whitespace or the enter after the number
	 * @param prompt: the question to ask the user 
	 * @return: a double value 
	 */
	public double inputDouble(String prompt) {
		System.out.print(prompt + "\n>");
		// if scanner does not see a double, get rid of garbage and ask again.
		while (!sc.hasNextDouble()) {
			String garbage = sc.nextLine();
			System.out.println("Didn't recognize " + garbage + " as a double.");
			System.out.println(prompt);
		}
		double num = sc.nextDouble();
		sc.nextLine(); // clear the buffer
		return num;
	}
	/**
	 * Prompt the user and read a boolean value, clearing whitespace or the enter after the number
	 * @param prompt: the question to ask the user 
	 * @return: a boolean value 
	 */
	public boolean inputBoolean(String prompt) {
		System.out.print(prompt + "\n>");
		// if scanner does not see a boolean, get rid of garbage and ask again.
		while (!sc.hasNextBoolean()) {
			String garbage = sc.nextLine();
			System.out.println("Didn't recognize " + garbage + " as a boolean value. Must enter: "
					+ "\"true\" or \"false\"");
			System.out.println(prompt);
		}
		boolean value = sc.nextBoolean();
		sc.nextLine(); // clear the buffer
		return value;
	}
	
	/**
	 * Prompt the user enter yes or no (will match y/yes and n/no any case) and return true for yes and false for no.
	 * @param prompt: the question to ask the user 
	 * @return: a boolean value 
	 */
	public boolean inputYesNoAsBoolean(String prompt) {
		System.out.print(prompt + "\n>");
		// if scanner is seeing BAD input... loop to get good input
		String answer = sc.nextLine().toLowerCase();
		while ( ! (answer.equals("y") || answer.equals("yes") 
					|| answer.equals("n") || answer.equals("no") )) {
		
			System.out.println("Didn't recognize " + answer + " as yes or no...");
			System.out.println(prompt);
			answer = sc.nextLine().toLowerCase();
		}
		//end of loop = good input
		
		if(answer.equals("y") || answer.equals("yes")) {
			return true;
		}
		else {
			return false;
		}
	}
	
	// prints the commands
	public void printCommands() {
		System.out.println("W: Move up \n A: Move left \n S: Move down \n D: Move right \n P: Print Character Symbols \n Help: Learn more about the game \n Q: Quit game");
	}
	
	
	// getter for commands
	public Command getCommand() {
		String command = inputCommands("Make your move.", "W", "A", "S", "D","P","Q", "help");
		command.toLowerCase();
		
		Command output = Command.HELP;
		switch(command) {
		case "w":
			output = Command.MOVE_UP;
			break;
		case "a":
			output = Command.MOVE_LEFT;
			break;
		case "s":
			output = Command.MOVE_DOWN;
			break;
		case "d":
			output = Command.MOVE_RIGHT;
			break;
		case "p":
			output= Command.PRINT_CHARS;
			break;
		case "q":
			output = Command.QUIT;
			break;
		case "help":
			output = Command.HELP;
			break;
		}
		return output;
		
		
	}

}