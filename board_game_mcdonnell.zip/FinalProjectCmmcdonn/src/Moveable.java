
/**
 * Description of code: Moveable interface to keep track of the objects that can be moved (only player right now)
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/5/2020
 * Email: cmmcdonn@usc.edu
 */
public interface Moveable {
	
	public boolean move(Location newLoc);
}
