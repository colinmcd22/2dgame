
/**
 /**
 * Description of code:Tile class that adds the gamepieces as gameObjects
 * as GameObjects
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/1/2020
 * Email: cmmcdonn@usc.edu
 */

import java.util.ArrayList;
import java.util.List;


public class Tile extends GameObject {
	private List<Entity> pieces;
	private Ground groundType;
	private Location location;

	//constructors
	public Tile(Ground ground, int row, int col) {
		this(new ArrayList<>(), ground, new Location(row, col));
	}
	

	public Tile(List<Entity> allPieces, Ground type, Location loc) {
		this.groundType = type;
		this.location = loc;
		this.pieces = allPieces;
	}
	
	
	public Tile(Entity starter, Ground type, Location loc) {
		this(new ArrayList<>(), type, loc);
		pieces.add(starter);
	}
	public Tile(Ground type, Location loc) {
		this(new ArrayList<>(), type, loc);
	}



	/**
	 * @return all the pieces in this square
	 */
	protected List<Entity> getPieces() {
		return pieces;
	}

	/**
	 * @param the piece to be added to the square
	 */
	protected void addPiece(Entity piece) {
		this.pieces.add(piece);
	}

	protected boolean removePiece(Entity piece) {
		boolean removed = this.pieces.remove(piece);
		return removed;
	}

	/**
	 * @return the type
	 */
	protected Ground getGroundType() {
		return groundType;
	}


	/**
	 * @param type the type to set
	 */
	protected void setGroundType(Ground type) {
		this.groundType = type;
	}
	
	public String getSimpleDisplay() {
		// if i just want to display the board with one character... what should I display for the tile?
		// 3 cases: empty, 1 piece, or lots of pieces
		
		// ONE POINT OF RETURN IN CODE
		String symbol = "";
		if(pieces.isEmpty()) {
			symbol = "" + this.getGroundType(); // symbol of ground
		}
		else if (pieces.size() == 1) {
			symbol = "" + this.pieces.get(0).getSymbol(); // string + char == string
		}
		else {
			symbol = "❌"; // more than one piece
		}
		
		return symbol;
	}
	
	
	public String toString() {
		return groundType.getType() + " square " + this.location + " containing: " +  getPiecesAsString();
	}
	/**
	 * @return
	 */
	private String getPiecesAsString() {
		String s = "";
		if(pieces.isEmpty()) {
			s = "No pieces on Tile";
		}
		else {
			for(Entity o: pieces) {
				s+= o.getSymbol() + ",";
			}
			s = s.substring(0, s.length() -1); // get rid of last comma
		}
		return s;
	}

}