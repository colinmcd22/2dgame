
/**
 * Description of code: NOT YET IMPLEMENTED (V2)
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/5/2020
 * Email: cmmcdonn@usc.edu
 */
public class Curser extends EnemyNPC{

}
