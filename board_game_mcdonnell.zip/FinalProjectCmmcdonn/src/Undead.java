
/**
 * Description of code: Undead class that is the highest enemy class that you can fight
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/1/2020
 * Email: cmmcdonn@usc.edu
 */
public class Undead extends Entity{

	/**
	 * @param row
	 * @param col
	 * @param symbol
	 * @param name
	 */
	protected int strength;
	protected int health;
	
	public Undead(int row, int col, EmojiCharacter symbol, String name) {
		super(row, col, symbol, name);
		this.strength = 4;
		this.health = 4;
		
	}

	/**
	 * @return health
	 */
	public int getHealth() {
		return this.health;
	}
	
	/**
	 * 
	 * @return strength
	 */
	public int getStrength() {
		return this.strength;
	}
	
	/**
	 * 
	 * @param health
	 */
	public void setHealth(int health) {
		this.health = health;
	}
	
}
