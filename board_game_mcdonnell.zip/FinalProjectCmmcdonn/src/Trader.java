
import java.util.ArrayList;

/**
 * Description of code:  Trader Ally that can trade with the player
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 
 * Email: cmmcdonn@usc.edu
 */
public class Trader extends AllyNPC{
	

	/**
	 * @param row
	 * @param col
	 * @param symbol
	 * @param name
	 */
	
	private ArrayList<Potions> potions;
	private ArrayList<Weapons> weapons;
	
	public Trader(int row, int col, EmojiCharacter symbol, String name) {
		super(row, col, symbol, name);
		this.weapons = weapons;
		this.potions = potions;
	}
	
	
	
	
	
	
	

}
