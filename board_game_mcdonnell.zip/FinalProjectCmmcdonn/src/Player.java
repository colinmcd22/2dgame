import java.util.ArrayList;

/**
 * Description of code: player class that extends human and implements the moveable interface so it can be moved
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/1/2020
 * Email: cmmcdonn@usc.edu
 */



public class Player extends Human implements Moveable{

	/**
	 * @param row
	 * @param col
	 * @param symbol
	 * @param name
	 */
	

	
	private ArrayList<Item> items;
	private int kills;
	

	public Player(int row, int col, EmojiCharacter symbol, String name, int currentHP, int currentStr, int kills, ArrayList<Item> items) {
		super(row, col, symbol, name, currentHP, currentStr);
		this.items = items;
		this.kills = kills;

	}
	
	//getter for kills
	public int getKills() {
		return this.kills;
		
	}
	
	//setter that adds health
	public void addHealth(int health) {
		this.health = health + health;
	}
	
	
	// setter that adds strength
	public void addStrength(int str) {
		this.strength = strength +str;
	}
	
	//setter that subtracts kills 
	public void subtractKills(int kills) {
		this.kills = kills - kills;
	}
	
	// setter that subtracts strength
	public void subtractStrength(int str) {
		this.strength = strength - str;
	}
	
	// setter that adds to kill
	public void addKill() {
		this.kills = kills +1;
	}
	
	// boolean to see if it moved
	public boolean move(Location newLoc) {
		return true;
	}

	// to string method
	public String toString() {
		return this.name + " has " + this.health + " health and " + this.strength + " strength.";
	}
	
	// getter for name
	public String getName() {
		return this.name;
	}
	
	
	// character descriptions
	public String talionDesc() {
		return "Talion is a great warrior that wields a sword to slice and dice his enemies. He is a well balanced fighter with medium health and strength.";
	}
	
	public String shivDesc() {
		return "Shiv is a nimble warrior that wields daggers. He has very strong attacks, but does not have much strength.";
	}

	//getter for health
	public int getHealth() {
		return this.health;
	}
	
	//getter for Str
	public int getStrength() {
		return this.strength;
	}
	
	//sets health
	public void setHealth(int health) {
		this.health = health;
	}
}
