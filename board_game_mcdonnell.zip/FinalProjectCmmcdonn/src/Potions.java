
/**
 * Description of code: Type of item that grants health (power)
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/2/2020
 * Email: cmmcdonn@usc.edu
 */
public class Potions extends Item{

	private int power;
	private int cost;
	
	public Potions(String name, String type, int power, int cost) {
		super(name,type);
		this.power = power;
		this.cost = cost;
	}
	
	/**
	 * to String for potions
	 */
	public String toString() {
		return super.getName() + ": Grants " + this.power + " health. Cost: " + cost + " kills";
	}
	
	//getter for power (health)
	public int getPower() {
		return this.power;
	}
	
	
	// getter for cost
	public int getCost() {
		return this.cost;
	}
}

