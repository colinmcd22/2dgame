
/**
 * Description of code: Highest class in the hierarchy of the game, allows for different pieces to be placed around the board all
 * as GameObjects
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 
 * Email: cmmcdonn@usc.edu
 */
public class GameObject {

}
