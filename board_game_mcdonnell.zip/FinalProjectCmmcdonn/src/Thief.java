
/**
 * Description of code: NOT YET IMPLEMENTED (V2)
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 
 * Email: cmmcdonn@usc.edu
 */
public class Thief extends EnemyNPC {

}
