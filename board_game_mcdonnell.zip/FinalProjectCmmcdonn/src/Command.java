
/**
 * Description of code: Command enum to hold the different names of commands
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/5/2020
 * Email: cmmcdonn@usc.edu
 */
public enum Command {
	
	MOVE_LEFT,
	MOVE_UP,
	MOVE_DOWN,
	MOVE_RIGHT,
	INTERACT,
	PRINT_CHARS,
	HELP,
	QUIT;
	

}
