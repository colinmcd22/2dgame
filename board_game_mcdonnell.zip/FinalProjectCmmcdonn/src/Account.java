import java.io.BufferedReader;
import java.io.FileReader;

/**
 * Description of code: This is the account class that holds the data for a user. A players username and score is stored here.
 * @author Colin McDonnell
 * ITP 265, 2020, Tea Section
 * Date: 5/5/20
 * Email: cmmcdonn@usc.edu
 */
public class Account {

	//instance variables stored in account
	private String username;
	private int score;
	
	/** constructor that passes in the username param
	 * @param username
	 */
	public Account(String username) {
		this.username = username;
		this.score = 0;
	}
	
	/** getter method for username
	 * @return username
	 */
	public String getUsername() {
		return username;
	}
	
	/** getter method for score(kills)
	 * @return score
	 */
	public int getScore() {
		return score;
	}
	
	/** returns the name from the file
	 * @return fileLine
	 */
	public String toFileString() {
		String fileLine = getUsername() + "/";
		return fileLine;
	}
	
	/** setter for score to add 1
	 * @param score
	 */
	public void addScore(int score) {
		this.score = score + score;
	}


}
